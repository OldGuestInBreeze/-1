﻿$ErrorActionPreference = 'Stop'

$jarDirectory = 'E:\鸿蒙软件开发综合实训资料分享\项目素材（学生用）\服务端Jar包和初始图标文件\jars'
$jarName = 'iteam-harmonyos-back-0.0.1-SNAPSHOT.jar'
$jarPath = "$jarDirectory\$jarName"

if (-not (Test-Path -LiteralPath $jarPath)) {
  Write-Host '找不到后端 JAR，请确认 E 盘项目素材没有移动。' -ForegroundColor Red
  exit 1
}

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
  Write-Host '找不到 Java，请先安装或配置 Java。' -ForegroundColor Red
  exit 1
}

$client = [System.Net.Sockets.TcpClient]::new()
try {
  $connect = $client.ConnectAsync('127.0.0.1', 3307)
  if (-not $connect.Wait(2000) -or -not $client.Connected) {
    throw 'MySQL 未启动'
  }
} catch {
  Write-Host '无法连接 MySQL 3307，请先启动 MySQL 服务。' -ForegroundColor Red
  exit 1
} finally {
  $client.Dispose()
}

$env:SPRING_DATASOURCE_DRUID_URL =
  'jdbc:mysql://127.0.0.1:3307/iteam01?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true'
$env:SPRING_DATASOURCE_DRUID_USERNAME = 'root'
$securePassword = Read-Host '请输入 MySQL 8.0 root 密码' -AsSecureString
$env:SPRING_DATASOURCE_DRUID_PASSWORD =
  [System.Net.NetworkCredential]::new('', $securePassword).Password

Set-Location -LiteralPath $jarDirectory
Write-Host '正在启动后端，请保持此窗口开启……' -ForegroundColor Cyan
& java -jar $jarPath
Write-Host "后端已停止，退出代码：$LASTEXITCODE" -ForegroundColor Yellow
